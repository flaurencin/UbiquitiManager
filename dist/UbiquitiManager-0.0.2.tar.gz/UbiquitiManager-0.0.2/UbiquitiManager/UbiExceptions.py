class UbiHttpException(Exception):
    pass


class UbiAuthException(Exception):
    pass


class UbiHostException(Exception):
    pass


class UbiConfigTest(Exception):
    pass


class UbiAlertConnectivityLost(Exception):
    pass


class UbiBadFirmware(Exception):
    pass
